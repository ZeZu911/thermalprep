ThermalPrep - Zero-Cloud 4x6 Shipping Label Cropper & Optimizer
===================================================================

Files included:
- index.html : The complete, standalone web application.

How to run:
1. Double-click index.html to run it locally in any browser (Chrome, Edge, Safari, Firefox).
2. To host it live for free on Netlify:
   - Go to https://app.netlify.com/drop
   - Drag and drop this unzipped folder into Netlify Drop.
   - Your site will be live on the web in 5 seconds!

Monetization included:
- Built-in Gumroad checkout link in the 'Support Tool' modal.
- SEO & Google Schema markup pre-configured.
- Tested thermal printing pipeline and sample label generator.
